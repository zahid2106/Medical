package com.example.cbcreport

import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.core.content.FileProvider

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { MaterialTheme { CbcApp() } }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CbcApp() {
    val ctx = LocalContext.current
    var name by rememberSaveable { mutableStateOf("") }
    var age by rememberSaveable { mutableStateOf("") }
    var sex by rememberSaveable { mutableStateOf("M") }
    var referredBy by rememberSaveable { mutableStateOf("Self") }
    val inputs = remember { mutableStateMapOf<String, String>() }

    val abnormal = CbcParams.count { p ->
        inputs[p.key]?.toDoubleOrNull()?.let { p.flag(it, sex) != null } == true
    }

    Scaffold(topBar = { TopAppBar(title = { Text("CBC Report") }) }) { pad ->
        Column(
            Modifier.padding(pad).padding(16.dp).verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Text("Patient details", style = MaterialTheme.typography.titleMedium)
            OutlinedTextField(name, { name = it }, label = { Text("Full name") },
                singleLine = true, modifier = Modifier.fillMaxWidth())
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(age, { age = it.filter(Char::isDigit) }, label = { Text("Age") },
                    singleLine = true, modifier = Modifier.weight(1f),
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number))
                OutlinedTextField(referredBy, { referredBy = it }, label = { Text("Referred by") },
                    singleLine = true, modifier = Modifier.weight(2f))
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf("M" to "Male", "F" to "Female").forEach { (k, l) ->
                    FilterChip(selected = sex == k, onClick = { sex = k }, label = { Text(l) })
                }
            }

            Text("Test values", style = MaterialTheme.typography.titleMedium)
            CbcParams.forEach { p ->
                val text = inputs[p.key] ?: ""
                val flag = text.toDoubleOrNull()?.let { p.flag(it, sex) }
                OutlinedTextField(
                    value = text,
                    onValueChange = { inputs[p.key] = it },
                    label = { Text("${p.name} (${p.unit})") },
                    supportingText = { Text("Ref: ${p.ref(sex)}") },
                    trailingIcon = {
                        if (flag != null) Text(flag, color = Color.Red, fontWeight = FontWeight.Bold)
                    },
                    isError = flag != null,
                    singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                    modifier = Modifier.fillMaxWidth().padding(start = if (p.indent) 16.dp else 0.dp)
                )
            }

            if (abnormal > 0)
                Text("$abnormal value(s) outside reference range. Please consult your doctor.",
                    color = Color.Red)

            Button(
                enabled = name.isNotBlank() && inputs.values.any { it.toDoubleOrNull() != null },
                modifier = Modifier.fillMaxWidth(),
                onClick = {
                    val values = CbcParams.mapNotNull { p ->
                        inputs[p.key]?.toDoubleOrNull()?.let { p.key to it }
                    }.toMap()
                    val file = PdfGenerator.create(ctx, Patient(name.trim(), age, sex, referredBy), values)
                    val uri = FileProvider.getUriForFile(ctx, "${ctx.packageName}.fileprovider", file)
                    val send = Intent(Intent.ACTION_SEND).apply {
                        type = "application/pdf"
                        putExtra(Intent.EXTRA_STREAM, uri)
                        addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                    }
                    ctx.startActivity(Intent.createChooser(send, "Share / save CBC report"))
                }
            ) { Text("Generate PDF report") }
        }
    }
}
