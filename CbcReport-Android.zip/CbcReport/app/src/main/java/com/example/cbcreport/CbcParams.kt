package com.example.cbcreport

data class CbcParam(
    val key: String,
    val name: String,
    val unit: String,
    val min: Double,
    val max: Double,
    val fMin: Double = min,          // female range (defaults to male)
    val fMax: Double = max,
    val maxExclusive: Boolean = false, // for "< 2" style ranges
    val minUnbounded: Boolean = false,
    val indent: Boolean = false
) {
    private fun lo(sex: String) = if (sex == "F") fMin else min
    private fun hi(sex: String) = if (sex == "F") fMax else max

    /** Returns "H", "L" or null (normal). */
    fun flag(v: Double, sex: String): String? = when {
        !minUnbounded && v < lo(sex) -> "L"
        v > hi(sex) || (maxExclusive && v >= hi(sex)) -> "H"
        else -> null
    }

    fun ref(sex: String): String =
        if (minUnbounded) "< ${fmt(hi(sex))}" else "${fmt(lo(sex))} - ${fmt(hi(sex))}"
}

fun fmt(d: Double): String =
    if (d % 1.0 == 0.0) "%,.0f".format(d) else d.toString()

val CbcParams = listOf(
    CbcParam("hb", "Hemoglobin", "g/dl", 13.0, 17.0, 12.0, 15.0),
    CbcParam("tlc", "Total Leukocyte Count", "cumm", 4800.0, 10800.0),
    CbcParam("neu", "Neutrophils", "%", 40.0, 80.0, indent = true),
    CbcParam("lym", "Lymphocyte", "%", 20.0, 40.0, indent = true),
    CbcParam("eos", "Eosinophils", "%", 1.0, 6.0, indent = true),
    CbcParam("mono", "Monocytes", "%", 2.0, 10.0, indent = true),
    CbcParam("baso", "Basophils", "%", 0.0, 2.0, maxExclusive = true, minUnbounded = true, indent = true),
    CbcParam("plt", "Platelet Count", "lakhs/cumm", 1.5, 4.1),
    CbcParam("rbc", "Total RBC Count", "million/cumm", 4.5, 5.5, 3.8, 4.8),
    CbcParam("hct", "Hematocrit (HCT)", "%", 40.0, 50.0, 36.0, 46.0),
    CbcParam("mcv", "MCV", "fL", 83.0, 101.0),
    CbcParam("mch", "MCH", "pg", 27.0, 32.0),
    CbcParam("mchc", "MCHC", "%", 31.5, 34.5)
)
