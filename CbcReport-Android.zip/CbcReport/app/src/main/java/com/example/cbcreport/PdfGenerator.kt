package com.example.cbcreport

import android.content.Context
import android.graphics.*
import android.graphics.pdf.PdfDocument
import java.io.File
import java.text.SimpleDateFormat
import java.util.*

data class Patient(val name: String, val age: String, val sex: String, val referredBy: String)

object PdfGenerator {
    private const val LAB_NAME = "Your Lab Name"   // TODO: change
    private const val LAB_CONTACT = "+91 12345 67890  |  yourlabname@gmail.com"
    private val BLUE = 0xFF0B4F82.toInt()

    fun create(ctx: Context, p: Patient, values: Map<String, Double>): File {
        val doc = PdfDocument()
        val page = doc.startPage(PdfDocument.PageInfo.Builder(595, 842, 1).create())
        val c = page.canvas

        fun paint(size: Float, bold: Boolean = false, color: Int = Color.BLACK) =
            Paint(Paint.ANTI_ALIAS_FLAG).apply {
                textSize = size; this.color = color
                typeface = if (bold) Typeface.DEFAULT_BOLD else Typeface.DEFAULT
            }

        // Header
        c.drawRect(0f, 0f, 595f, 90f, Paint().apply { color = BLUE })
        c.drawText(LAB_NAME, 30f, 45f, paint(24f, true, Color.WHITE))
        c.drawText(LAB_CONTACT, 30f, 70f, paint(10f, false, Color.WHITE))

        // Patient block
        val now = SimpleDateFormat("dd/MM/yyyy hh:mm a", Locale.getDefault()).format(Date())
        c.drawText(p.name, 30f, 118f, paint(13f, true))
        c.drawText("Age / Sex : ${p.age} YRS / ${p.sex}", 30f, 136f, paint(10f))
        c.drawText("Referred by : ${p.referredBy.ifBlank { "Self" }}", 30f, 152f, paint(10f))
        c.drawText("Reported on : $now", 340f, 136f, paint(10f))
        c.drawLine(30f, 165f, 565f, 165f, paint(1f))

        // Title
        val center = paint(13f, true).apply { textAlign = Paint.Align.CENTER }
        c.drawText("HAEMATOLOGY", 297f, 190f, center)
        c.drawText("COMPLETE BLOOD COUNT (CBC)", 297f, 206f, paint(11f, true).apply { textAlign = Paint.Align.CENTER })

        // Table header
        var y = 232f
        val h = paint(10f, true)
        c.drawText("TEST", 30f, y, h); c.drawText("VALUE", 270f, y, h)
        c.drawText("UNIT", 350f, y, h); c.drawText("REFERENCE", 460f, y, h)
        c.drawLine(30f, y + 6, 565f, y + 6, paint(1f))
        y += 24f

        for (prm in CbcParams) {
            val v = values[prm.key] ?: continue
            val f = prm.flag(v, p.sex)
            val pt = paint(10.5f, f != null)
            val x = if (prm.indent) 46f else 30f
            c.drawText(prm.name.uppercase(), x, y, pt)
            if (f != null) c.drawText(f, 245f, y, pt)
            c.drawText(fmt(v), 270f, y, pt)
            c.drawText(prm.unit, 350f, y, pt)
            c.drawText(prm.ref(p.sex), 460f, y, pt)
            y += 22f
        }
        c.drawLine(30f, y - 8, 565f, y - 8, paint(1f))

        // Notes
        y += 20f
        c.drawRect(30f, y, 565f, y + 70f, Paint().apply { color = 0xFFF1F4F9.toInt() })
        c.drawText("Clinical Notes:", 40f, y + 18f, paint(10f, true))
        c.drawText("CBC is used to evaluate overall health and detect disorders such as anemia,", 40f, y + 34f, paint(9f))
        c.drawText("infection and leukemia. H = above range, L = below range.", 40f, y + 47f, paint(9f))
        c.drawText("Please correlate clinically and consult your doctor.", 40f, y + 60f, paint(9f))

        // Footer
        c.drawRect(0f, 790f, 595f, 842f, Paint().apply { color = BLUE })
        val fp = paint(9f, false, Color.WHITE).apply { textAlign = Paint.Align.CENTER }
        c.drawText("Self-entered report - NOT VALID FOR MEDICO LEGAL PURPOSE", 297f, 812f, fp)
        c.drawText("Values were entered by the user; verify with your lab report.", 297f, 826f, fp)

        doc.finishPage(page)
        val dir = File(ctx.cacheDir, "reports").apply { mkdirs() }
        val file = File(dir, "CBC_${p.name.replace(" ", "_")}.pdf")
        file.outputStream().use { doc.writeTo(it) }
        doc.close()
        return file
    }
}
